# Take-off note — house water system

Taken off as at 15 September 2026, following the rules in `takeoff_rules.md`.

The register marks 11 runs that take a reducer. It marks 3 runs that take a coupler.

Two runs are unresolved: C-10 and C-24. Each lands on a pump suction port whose in-force manufacturer table states no size (the TJ-100 and the TJ-200 suction ports), so these two cannot be taken off until those ports are measured.

Two further fittings are needed but are not stocked in the catalogue and must be sourced elsewhere: C-04 (a 1-1/4 BSP × 1 BSP reducer, where RD-114-1-B is discontinued with no replacement) and C-20 (a 1 NPT × 1-1/4 BSP adapter, for which no stocked line exists).

Three re-routed runs were withdrawn by their replacements and carry no row, so no pipe is cut for them: C-03, C-07 and C-17. Total pipe to cut for the taken-off runs is 181.5 ft.
