# Take-off note — house water system

Take-off as at 2026-09-15.

The register calls for a reducer on 10 connections and a coupler on 4 connections.

Two runs are unresolved — C-10 and C-24 — because the pump suction port size is not yet stated by the manufacturer, so no fitting can be selected for them.
