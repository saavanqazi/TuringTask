# Take-off note — house water system

Take-off made 15 September 2026, from the runs in `connections.csv` read against the makers' published port tables (`spec_sheet.md`) and the supplier's `fitting_catalog.csv`. Runs that another run replaces carry no row and are not counted.

The register calls for **11 reducer** fittings and **3 coupler** fittings. A further eight runs take thread adapters, which are not counted here.

Two runs are unresolved: C-10 and C-24. Each meets a jet-pump suction port whose size the maker's current table does not state, so no fitting can be selected for it until that port is measured on the unit.

Two further runs in the register show `NONE` for their fitting (one reducer, one adapter): the only matching catalogue row is discontinued with no stocked successor, so those two fittings must be sourced elsewhere before those runs close.
