# Take-off note — house water system

For the plumbing supplier: 11 connections need a reducer and 3 need a coupler; a further 8 take an adapter. Total pipe to cut is 181.5 ft.

Two connections are still unresolved — C-10 and C-24 — because each ends at a pump suction port whose size the manufacturer has not stated in the revision in force at the 15 September 2026 take-off (the TJ-100 and TJ-200 suction ports); measure those ports before those runs can be taken off.

Two more runs have a known fitting but no stocked match in your catalogue, so the fitting will need sourcing elsewhere: C-04 (a 1-1/4 BSP to 1 BSP reducer, where the catalogue row is discontinued) and C-20 (a 1 NPT to 1-1/4 BSP adapter, not listed as stocked).
