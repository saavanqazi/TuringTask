# Take-off note — house water system

Take-off as at 15 September 2026.

11 connections need a reducer and 3 connections need a coupler. A further 8 take an adapter from stock.

Connections C-10 and C-24 are unresolved. Each lands on a pump suction port whose manufacturer states no size in the revision in force on the take-off date, so no fitting can be selected until the port is measured.
