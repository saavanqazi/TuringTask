# tech-b53-t9-water-system-fitting-takeoff


## 1. Task description

A homeowner is plumbing a house water system: storage tanks feed jet pumps, and the pumps
feed pressure vessels. Before ordering, they want a fitting take-off for every pipe run.
The agent receives six files under `/app/input`:

- the kit's ports as the retailer listed them (`components.csv`, 20 ports);
- the makers' published port tables with dated revisions (`spec_sheet.md`);
- every pipe run with its length, including runs since re-routed (`connections.csv`, 27 runs);
- the supplier's catalogue with stock status (`fitting_catalog.csv`, 21 rows);
- the governing rules (`takeoff_rules.md`, Rev C, T1–T10);
- the output contract (`submission_format.md`).

It must deliver three files:

- `/app/fitting_register.csv`: one row per connection taken off, with the catalogue fitting and its kind (`COUPLER`, `REDUCER`, `ADAPTER` or `UNRESOLVED`);
- `/app/takeoff_note.md`: a short note for the supplier with the reducer and coupler counts, naming each unresolved connection;
- `/app/results.json`: three counts and the pipe total.

The population is not handed over. Which runs are taken off (3 of the 27 are withdrawn by
the `replaces` column) and each port's size must both be derived:

- A size comes from the maker's table revision **in force on 2026-09-15**. Some revisions take effect exactly on that date, others later, and publication dates are irrelevant.
- The retailer's `listed_size_in` is never used.
- DN sizes are mapped to inches.
- Sizes are compared numerically across fraction, decimal and DN notation.
- Only `STOCKED` catalogue rows can be selected, with each end matched on both size and thread.

The key has 24 rows: 11 reducers, 3 couplers, 8 adapters and 2 unresolved (C-10, C-24), with 181.5 ft of pipe.

## 2. Departures from the mined version

The mined version is listed in the trainer's inventory of the tracker zip.

| File | Mined | Now | Why |
|---|---|---|---|
| all text files | CRLF line endings | LF | FIX-10. Under plain Linux bash, the CRLF `solve.sh` stops at `set -euo pipefail`. |
| `instruction.md` | template block ("must be your final action; confirm each one exists", "Working environment"), relative `input/` paths | natural request of about 150 words, one line per input file, deliverables as `/app/...` paths | INS-1, INS-13, INS-15 |
| `environment/input/takeoff_rules.md` | Rev B, T1–T8; T2 "touching that component" was ambiguous; T8 "counted by neither" | Rev C, T1–T10 (details below this table) | Ambiguities removed (GLD-5); difficulty via sanctioned patterns (Standard 3.3) |
| `environment/input/spec_sheet.md` | one table per product | effective- and publication-dated revisions for TJ-100, TJ-200, BJ-75, HJ-1 and PV-44; new products CT-300, TJ-200, AF-40 (DN) and AV-50 (DN) | Stale-authority and cross-source patterns |
| `environment/input/components.csv` | 14 ports | 20 ports | New products |
| `environment/input/connections.csv` | 16 runs | 27 runs with a `replaces` column (3 withdrawn); IDs assigned with a fixed seed, not in file order | Unit of analysis / state across steps |
| `environment/input/fitting_catalog.csv` | 16 rows | 21 rows with `status` and `superseded_by` (2 `DISCONTINUED`, one listed before its replacement) | Disclosed tie-breaker; status derivable from a field (FIX-4) |
| `environment/input/submission_format.md` | regex-style note rules, "at least sixty words" | plain list of the checked facts; register = connections taken off | Realism, INS-12 |
| `tests/verifier.json` | 13 checks (6 incidental, 2 existence-only; C-03 split into its own check) | 7 core checks, all generated | Only core ships; VER-21, VER-26, O14 |
| `tests/verifier.json` (Delivery Gate round) | `register_header` case-insensitive; `fitting_id`/`fitting_kind` graded as casefolded text; note counts graded as co-occurrence of a number and a word in one sentence; unresolved IDs graded as co-occurrence with "unresolved" in one paragraph | header case-sensitive; `fitting_id`/`fitting_kind` graded case-sensitively (engine cell type `id`); each note count must be the number stated **for** its word (no other number or fitting word between, not a hedge, not bound to another fitting word); an unresolved ID must not be called "resolved" | Gate findings layer5 coverage_depth and surface_form_brittleness: swapped counts ("11 couplers and 3 reducers"), "C-10 is resolved" and a lower-case register used to pass. Checks only; instruction, inputs and gold byte-identical, so the shipped runs were re-graded rather than re-run: rewards unchanged |
| `tests/verifier.json` (Delivery Gate round 2) | unresolved checks banned the standalone word "resolved"; count checks banned any fitting word between a number and its word | both bans removed, because neither is stated in `submission_format.md` (gate: requirement_traceability, surface_form_brittleness). Unresolved: only IDs of unresolved connections listed together may stand between an ID and "unresolved", which is the stated rule. Counts: no other number between; a number directly bound to another fitting word, or a hedge, is not the count | Checks only; instruction, inputs and gold byte-identical; shipped runs re-graded, rewards unchanged |
| `tests/verifier.json` (Delivery Gate round 3) | count checks banned any number between a count and its word; the unresolved list joiner did not accept a line break | count checks now ban only a *competing count* (another number attached to a fitting word), so "11 of the 24 runs take reducers" and "Reducers (C-06, C-14): 11" pass while swapped and zero counts still fail; the unresolved joiner accepts a line break, a bullet, a semicolon and a parenthetical after an ID | Gate: representation_contract, surface_form_brittleness. Checks only; instruction, inputs and gold byte-identical; shipped runs re-graded, rewards unchanged |
| `tests/manifest.json` | absent | byte-identical copy of `verifier.json` | The upload validator requires it (lead ruling) |
| `tests/score.py` | two-tier core + incidental weights; engine errors counted as fails | binary reward; an errored check is listed separately and exits 2 | HAR-2, HAR-6 |
| `tests/test.sh` | ran from `/app` with a bare `python3`; `reward.txt` missing on a crash | `reward.txt` written first; runs from `/tests` with `/usr/local/bin/python3 -I`, fixed PATH, no PYTHONPATH, `--rootdir=/tests`, `-p no:cacheprovider` | HAR-1, HAR-9, EXP-8 |
| `tests/generate_fixture.py`, `tests/probe_suite.py`, `tests/input_hashes.json` | absent | seeded generator (inputs, gold and checks from one source), discrimination harness, input hashes | FIX-9, VER-24, FIX-11 |
| `solution/files/*` | hand-made gold | regenerated by `generate_fixture.py` | GLD-11 |
| `solution/golden_trajectory.json` | synthetic list of `printf` commands | the `agent/trajectory.json` of the reward-1.0 GLM-5.2 run shipped in `evaluations/solvability/r1` | PKG-8 |
| `solution/solve.sh` | emitted a trajectory from a command list | also accepts an ATIF golden trajectory | Follows from the golden trajectory change |
| `task.toml` | `artifacts = []` | the three `/app/...` paths; `metadata.reward_shape` declared | TOML-4, HAR-2 |
| `environment/Dockerfile`, `.dockerignore` | base image by tag; no `.dockerignore` | base pinned by digest; `.dockerignore` is `*`, `!Dockerfile`, `!input/`, `!input/**`, the only negation shape the sandbox provider accepts | ENV-3, ENV-8; PreQC QC1-1 (PF2.provider_image_compatibility) rejected the earlier `!input` form |
| `tests/rl_world_verifiers/` | 24 compiled `.pyc` modules with no source | the same engine as `.py` source (24 modules + `py.typed`), taken from an accepted client bundle; each module compiles under Python 3.12 to bytecode identical to the shipped `.pyc` (code, constants, names, arguments) | PreQC QC1-2..QC1-25 (PF3.compiled_python); VER-30 engine unchanged |
| `consistency/`, `evaluations/oracle/`, `evaluations/nop/` | present (mining-tool output with a personal Windows path) | removed | PKG-1, EVD-1, TOML-10 |

The rule changes in `takeoff_rules.md` (Rev C):
- the take-off date 2026-09-15 is stated;
- T1: withdrawn (re-routed) runs;
- T2: the revision in force is the latest effective on or before the take-off date, and the publication date plays no part;
- T4: an unstated port affects only that `component_id`;
- T5: DN sizes are mapped to inches;
- T7: only `STOCKED` rows count, each end is matched on size and thread, and the catalogue row's kind must equal the T6 kind;
- T10: "none of them".

## 3. Declarations

- **Reward shape:** binary. Every check is core, and the reward is 1.0 only when all 7 pass, else 0.0. This is declared in `task.toml` `metadata.reward_shape` and implemented in `tests/score.py`.
- **Checks (7, all core, all deterministic):**
  - `register_header`: the three column names exactly as written (case-sensitive), tolerating a BOM, CSV quotes and spaces around commas.
  - `register_table`: `table_equals` over all 24 rows, with the ordered population lock and the closed column set; `fitting_id` and `fitting_kind` compared case-sensitively (cell type `id`).
  - `results_figures`: `object_equals` over the closed key set; counts exact, total within 0.01.
  - `note_reducer_count` and `note_coupler_count`: the count and the word in the same sentence, either order, digits or words, as that word's number. The count must not itself be attached to another fitting word ("11 couplers"). No competing count (another number attached to a fitting word, e.g. "0 couplers") may stand between them. It must not be a hedge ("11 or 12"). Other numbers and IDs may stand between ("11 of the 24 runs take reducers", "Reducers (C-06, C-14): 11"). Swapped counts fail both.
  - `note_unresolved_C-10` and `note_unresolved_C-24`: the ID and "unresolved" in the same paragraph, either order. Any ID between them must belong to the unresolved connections listed together with it: joined by commas, semicolons, "and", "&", "/", a line break or a bullet, each optionally followed by a parenthetical. This is the rule `submission_format.md` states, with no word lists.
- **Checks files:** `tests/verifier.json` is what the engine, `score.py` and `test_outputs.py` load. `tests/manifest.json` is a byte-identical copy that exists only for the upload validator.
- **Judge:** none. There is no LLM rubric, so `JUDGE_MODEL` plays no part.
- **Network:** `network_mode = "public"`, an ENV-4 exception. With `"no-network"`, harbor's opencode agent could not install its own dependencies (`apt-get install nodejs npm` could not reach `deb.debian.org`; job `glm-smoke-day2`, `NonZeroAgentExitCodeError`). The agent also has to reach the model gateway. The verifier needs no network.
- **Deliverable carriers (PKG-13):** a CSV register is what a supplier order is picked from, a short markdown note is what a homeowner hands over, and a JSON totals file is the machine summary.
- **Evidence format:** harbor writes neither `verifier/reward.json` nor `verifier/verifier_summary.json`, and its `result.json` has no `model`, `overall_pass`, `reward`, `final_answer` or judge fields. These were added to each shipped run by the fallback annotator (`assemble_evidence.py --annotate`), without changing harbor's own fields. The team's `annotate_rollout.py` was not used.

## 4. Golden key derivation (Stage 6)

The key is produced by `tests/generate_fixture.py`. Its `solve()` re-derives the answer by
parsing the written input files. Every trap row was re-derived by hand from the documents:

| Row | Ports as read | Result | Rule |
|---|---|---|---|
| C-10 | TK-A (1-1/2 NPT) → P1-S: TJ-100 suction not stated in Rev 1; Rev 2 is effective 2026-10-01, not in force | NONE / UNRESOLVED | T2, T4 |
| C-24 | TK-D → P6-S: TJ-200 suction not stated in Rev 1; Rev 2 is effective 2026-09-16, the day after | NONE / UNRESOLVED | T2, T4 |
| C-19 | P4-D: HJ-1 Rev 2 is effective **on** 2026-09-15, so it is in force → 1.25 NPT vs V1 1 NPT | RD-114-1-N / REDUCER | T2 (on or before), T5 |
| C-22 | P4-D 1.25 NPT vs V2 (PV-44 Rev A 1-1/4; Rev B effective 2026-11-01) | CP-114-N / COUPLER | T2, T5 |
| C-14 | P2-D: TJ-150 table gives 1 (the retailer lists 1-1/4) vs V2 1-1/4 NPT | RD-114-1-N / REDUCER | T3 |
| C-04 | P3-D: BJ-75 Rev 2 (2026-06-01) gives 1 BSP vs V4 DN32 = 1-1/4 BSP; RD-114-1-B is `DISCONTINUED` | NONE / REDUCER | T2, T5, T7 |
| C-05 | P3-D 1 BSP vs V2 1-1/4 NPT | AD-114N-1B / ADAPTER | T2, T6, T7 |
| C-13, C-23 | 1-1/4 BSP vs 1-1/4 NPT; AD-114B-114N (`DISCONTINUED`, listed first) skipped | AD-114N-114B / ADAPTER | T7 |
| C-20 | P1-D 1 NPT vs V4 1-1/4 BSP; AD-114N-1B has the threads on the other ends | NONE / ADAPTER | T7 (size and thread per end) |
| C-01, C-25, C-12 | DN40, DN25 and DN25 read as 1-1/2, 1 and 1 | RD-112-114-B, RD-1-34-B, AD-1B-1N | T5 |
| C-03, C-07, C-17 | named in `replaces` of C-27, C-20 and C-15 | no register row | T1 |

- **Totals:** 11 REDUCER + 3 COUPLER + 8 ADAPTER + 2 UNRESOLVED = 24 rows.
- **Pipe:** 181.5 ft, the sum over the 22 rows not UNRESOLVED, re-added by hand.
- **Self-consistency (GLD-2):** rows whose two ports read as the same sizes and threads get identical answers. For example, C-06 (P1-D → V2) and C-14 (P2-D → V2) are both 1 NPT to 1-1/4 NPT, and both give RD-114-1-N.
- **Construction leaks (GLD-7):** the gold note contains none of "intended", "should be", "we set" or "resolved by".

## 5. Difficulty design: expected wrong readings (declared before the `glm-4x-day3` battery)

| # | Wrong reading | Rows it changes |
|---|---|---|
| W1 | retailer `listed_size_in` instead of the maker's table | C-04, C-05, C-10, C-11, C-14, C-19, C-22, C-24 |
| W2 | newest revision even when not yet in force | C-05, C-06, C-10, C-14, C-16, C-22, C-24 |
| W3 | first revision listed | C-04, C-05, C-06, C-10, C-14, C-16, C-22, C-24 |
| W4 | revision effective ON 2026-09-15 treated as not in force | C-19, C-22 |
| W5 | sizes compared as text | C-01, C-02, C-12, C-15, C-19, C-21, C-22, C-23, C-25 |
| W6 | catalogue end order must follow from → to | C-01, C-05, C-06, C-13, C-14, C-26 |
| W7 | a `DISCONTINUED` row selected | C-04, C-13, C-23 |
| W8 | withdrawn runs kept | adds C-03, C-07, C-17 |
| W9 | ends matched on size, threads only as a set | C-20 |
| W10 | a whole product marked unresolved when one port is unstated | C-06, C-08, C-16, C-20, C-23 |

The rules were hardened from the mined version until the battery fell inside the band. A
first battery on the cleaned but unhardened version passed every run.

## 6. Probes and solvers (`tests/probe_suite.py`, 65 cases, `PROBLEMS: 0`)

- **Gold:** 1.0.
- **Equivalent rewrites that still pass:** reordered JSON keys, every CSV field quoted, CRLF everywhere, no trailing newline, a UTF-8 BOM, counts as N.0, a trailing zero on the total, an extra scratch file.
- **Breaking cases that fail on the named check:**
  - flipped kind, dropped row, spurious row, a withdrawn row kept, and swapped row order (`register_table`);
  - count +1, and the total including the unresolved runs (`results_figures`);
  - emptied register;
  - deleted `results.json` or `{}` (`results_figures`);
  - deleted note (all note checks);
  - register lower-cased, and a single `fitting_id` lower-cased (`register_table`).
- **Decoy solvers, one per wrong reading W1–W10:** every one fails, and only on the rows listed in §5.
- **Degenerate floor, all failing:**
  - majority class (every row REDUCER/NONE);
  - the instruction pasted as the note;
  - `connections.csv` copied as the register;
  - an empty workspace.
- **Note wording:** paraphrased, reversed, number-word, bulleted, CRLF+BOM, label-first ("Connections needing a reducer: 11"), both counts in one sentence, and counts in parentheses all pass. These all fail:
  - a wrong number, or the number in another sentence;
  - counts swapped ("We need 11 couplers and 3 reducers"), either order;
  - zero counts with the right numbers elsewhere;
  - a hedged count ("11 or 12");
  - a missing ID, or the ID in another paragraph;
  - a non-unresolved ID between an ID and "unresolved";
  - "C-10 is resolved, C-24 unresolved", and "C-10 is resolved" in a later sentence.
- **Note wording, gate round 2:** these pass:
  - "C-10 is unresolved (not resolved yet).";
  - "C-10 and C-24 cannot be resolved yet; both are unresolved.";
  - "Eleven of the non-adapter connections need reducers";
  - "Two runs remain unresolved: C-10 and C-24.".

  These fail:
  - an unresolved ID with an unlisted ID before the word ("C-10 was measured on site. C-24 is unresolved.");
  - a count bound to another fitting word ("11 couplers and reducers").
- **Note wording, gate round 3:** these pass:
  - "11 of the 24 runs take reducers and 3 of the 24 runs take couplers";
  - "Reducers (C-06, C-14, C-19): 11 needed";
  - a soft-wrapped "C-10\nC-24 are unresolved";
  - a bulleted list of IDs;
  - bold "**11 reducer** fittings".

  Every earlier counterexample still fails.
- **Re-grade after the check changes:** the five shipped runs' `artifacts/app` were graded again with the current checks: r1 1.0, r2 0.0, r3 1.0, r4 1.0, solvability 1.0, the same as recorded.

## 7. Environment tests

- **Oracle:** reward 1.0 (local job `oracle-day3`), and again on the assembled bundle: `oracle-submit` = 1.0.
- **Harness, with the shipped `test.sh` logic:** gold 1.0; an empty workspace 0.0; deliverables replaced by symlinks 0.0; a planted `/app/conftest.py` and `/app/sitecustomize.py` have no effect.
- **Containment (ENV-7), fresh container of the shipped image (`docker build -t b53t9-submit`, base pinned by digest `sha256:392307d22300de8b5986851a12d9176dfc0fc073e65bf6523ebd7dcbeb23564e`):**

```
docker run --rm b53t9-submit bash -c "find / \( -name solve.sh -o -name test.sh -o -name verifier.json -o -name manifest.json -o -name generate_fixture.py -o -name probe_suite.py \) -not -path '/proc/*' 2>/dev/null; echo ---; ls -d /tests /solution 2>&1; echo ---; ls /app /app/input"
---
ls: cannot access '/tests': No such file or directory
ls: cannot access '/solution': No such file or directory
---
/app:
input

/app/input:
components.csv
connections.csv
fitting_catalog.csv
spec_sheet.md
submission_format.md
takeoff_rules.md
```

  Nothing is listed before the first `---`, `/tests` and `/solution` are absent, and `/app` contains only `input` with the six input files.

## 8. Trial results (GLM-5.2, opencode harness, job `glm-4x-day3`)

| Run | Trial | Reward | Classification |
|---|---|---|---|
| r1 | `…__3YJaa2e` | 1.0 | pass |
| r2 | `…__dy4QzNT` | 0.0 | **MODEL**, matches W1. It read the TJ-150 discharge as 1-1/4 from the retailer's listing instead of the maker's 1. That made C-14 COUPLER `CP-114-N` (expected REDUCER `RD-114-1-N`) and C-11 `NONE` (expected `AD-1N-34B`). `results_figures` and both note counts follow from the same error. |
| r3 | `…__GHF3i5b` | 1.0 | pass |
| r4 | `…__GSXsk6t` | 1.0 | pass |

The r1–r4 mapping matches what `assemble_evidence.py` printed.
- **Strict passes:** 3 of 4.
- **Infra:** no run crashed, and no run is excluded.
- **Solvability:** `evaluations/solvability/r1` (trial `…__x48rMM7`) is a separate reward-1.0 GLM-5.2 run on the same package (job `glm-smoke-day3`). Its trajectory is `solution/golden_trajectory.json`.

## 9. Isolation proof

- `environment/Dockerfile` copies `input/` only, and `.dockerignore` admits only the Dockerfile and `input/`.
- `solution/` and `tests/` never enter the agent's container; see the containment output in §7.
- No reward-bearing check reads `/app/input`: every expected value is fixed in `tests/verifier.json`, and the input hashes are pinned in `tests/input_hashes.json`.

## 10. Reproduction

```
python tests/generate_fixture.py      # regenerates inputs, gold, verifier.json and manifest.json byte-identically
python tests/probe_suite.py           # prints PROBLEMS: 0
harbor run -p <task> -a oracle -o <jobs> --job-name oracle-check -n 1 -y     # reward 1.0
```