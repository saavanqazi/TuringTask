#!/usr/bin/env python3
"""score.py - turn per-check outcomes into one reward.

Reward shape: binary. Every check in verifier.json is core. The reward is 1.0 when
every check passes and 0.0 otherwise.

A check that fails is different from a check that ERRORS (the engine raised instead of
returning a verdict). An errored check is listed under "errored", the reward is 0.0, and
the script exits 2 so the harness marks the run ineligible rather than counting it as a
model failure (Standard HAR-6).
"""
import json
import os
import sys
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(TESTS_DIR))

from rl_world_verifiers.models import VerifierSpec, effective_weights
from rl_world_verifiers.sources.registry import SourceRegistry
from rl_world_verifiers.verifiers import verify_definition

WORKSPACE = Path(os.environ.get("HARBOR_TASK_WORKSPACE", "/app"))
# Harbor mounts the agent trajectory under /logs/agent. Passing it through makes
# `response.*` sources (grade the agent's final chat message) resolvable; when the
# directory is absent those sources fail with the engine's own precondition error
# instead of an unknown-registry crash, and every other source is unaffected.
AGENT_LOGS = Path(os.environ.get("HARBOR_AGENT_LOGS_DIR", "/logs/agent"))
SPEC = VerifierSpec.model_validate_json((TESTS_DIR / "verifier.json").read_text(encoding="utf-8"))
WEIGHTS = effective_weights(SPEC.verifiers)
REGISTRY = SourceRegistry(WORKSPACE, agent_logs_dir=AGENT_LOGS if AGENT_LOGS.is_dir() else None)

results, failures, errored = [], [], []
for definition in SPEC.verifiers:
    try:
        outcome = verify_definition(
            definition, REGISTRY, WEIGHTS[definition.name],
            config=SPEC.config, completion_fn=None,
        )["result"]
        ok = bool(outcome["success"])
        detail = outcome.get("error") or outcome.get("reason") or ""
        state = "passed" if ok else "failed"
    except Exception as exc:  # an engine error is never a silent pass, and never a plain fail
        ok, detail, state = False, f"{type(exc).__name__}: {exc}", "errored"
        errored.append(definition.name)
    tag = definition.metadata.tag or "core"
    results.append({"name": definition.name, "tag": tag, "passed": ok, "state": state,
                    "weight": WEIGHTS[definition.name], "detail": str(detail)[:200]})
    if state == "failed":
        failures.append(definition.name)

reward = 1.0 if not failures and not errored else 0.0
print(json.dumps({
    "reward": reward,
    "reward_shape": "binary: all checks are core; 1.0 only when every check passes",
    "core_failures": failures,
    "errored": errored,
    "passed": sum(1 for r in results if r["passed"]),
    "total": len(results),
    "checks": results,
}, indent=2))
sys.exit(2 if errored else 0)
