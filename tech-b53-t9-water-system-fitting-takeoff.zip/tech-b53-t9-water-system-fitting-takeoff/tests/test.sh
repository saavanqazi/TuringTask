#!/bin/bash
# Harbor verifier entrypoint. Harbor copies this to /tests/test.sh; the reward is read
# back from /logs/verifier/reward.txt.
#
#   1. pytest writes the per-check grid and the CTRF report (one test per check).
#   2. score.py decides the reward: binary, 1.0 only when every core check passes.
#
# reward.txt is written as 0 first, so it exists on every path, including a crash.
# The grader runs from /tests with a fixed interpreter, isolated mode (-I), a fixed PATH,
# no PYTHONPATH and no pytest cache, so nothing the agent leaves in /app can shadow it.
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

cd /tests || exit 1
PY=/usr/local/bin/python3
export PATH=/usr/local/bin:/usr/bin:/bin
unset PYTHONPATH

"$PY" -I -m pytest --rootdir=/tests -p no:cacheprovider \
    --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA

"$PY" -I /tests/score.py > /logs/verifier/score.json
status=$?

"$PY" -I -c "import json;print(json.load(open('/logs/verifier/score.json'))['reward'])" \
    > /logs/verifier/reward.txt 2>/dev/null || echo 0 > /logs/verifier/reward.txt

cat /logs/verifier/score.json
# exit 2 = a check errored (engine fault, not a model failure): the run is ineligible
if [ "$status" -eq 2 ]; then exit 2; fi
exit 0
