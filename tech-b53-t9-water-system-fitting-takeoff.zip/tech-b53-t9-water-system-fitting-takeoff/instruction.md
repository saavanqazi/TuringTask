I'm plumbing the water system for our house: storage tanks feed jet pumps, and the pumps feed pressure vessels. Before I order anything, I need a proper take-off of the fitting every pipe run needs. Everything is in `/app/input`:

- `components.csv` lists every port on the kit, as the retailer listed it.
- `spec_sheet.md` has the makers' own published port tables, with their revisions.
- `connections.csv` is every run between two ports, with its length.
- `fitting_catalog.csv` is my plumbing supplier's catalogue.
- `takeoff_rules.md` is how I want the take-off worked.

Please save three files:

- `/app/fitting_register.csv`, with the fitting each connection takes.
- `/app/takeoff_note.md`, a short note I can hand the supplier. It should give the reducer and coupler counts and flag any connection that can't be taken off yet.
- `/app/results.json`, with the totals.

The layout for all three is in `/app/input/submission_format.md`.
