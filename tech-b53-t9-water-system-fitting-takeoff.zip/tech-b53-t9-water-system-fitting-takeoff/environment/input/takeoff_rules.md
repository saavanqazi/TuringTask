# Fitting take-off rules — house water system (Rev C)

These rules are the sole authority for the fitting each connection takes. The
connections are in `connections.csv`; each port is in `components.csv`; the sizes the
makers state are in `spec_sheet.md`; the supplier's catalogue is `fitting_catalog.csv`.

The take-off is made as at **15 September 2026**. All dates are written `YYYY-MM-DD`.

## T1  Which connections are taken off

`connections.csv` still carries runs that have since been re-routed. Where a connection's
`connection_id` appears in the `replaces` column of another connection, it is WITHDRAWN:
it gets no row in the register, it is counted by none of the counts, and no pipe is cut
for it. Every other connection is taken off, replacements included, unless another
connection replaces them in turn. A blank `replaces` means the connection replaces
nothing.

## T2  Which revision of a maker's table is in force

Makers publish revised port tables, sometimes ahead of the date they take effect. The
revision in force for a product is the one with the latest effective date **on or
before** the take-off date; a revision whose effective date falls after the take-off date
is not yet in force. The publication date plays no part. A revision's table replaces the
earlier table whole.

## T3  Where a port's size and thread come from

A port's SIZE is the size the manufacturer states for the component's `product` and
`port_role` in the revision in force (T2). A port's THREAD is the `thread` column of
`components.csv`. The `listed_size_in` column of `components.csv` is what the retailer's
listing says; it is carried for reference and no rule below reads it.

## T4  A port the manufacturer does not state

Where the revision in force says in words that the manufacturer states no size for a
port, every connection that has that port (its `component_id` in `components.csv`) at
either end is `UNRESOLVED`, and its `fitting_id` is `NONE`. The other ports of the same
product are unaffected: each is read from its own row of the maker's table. No size is
taken from a listing, a kit, a description or a revision not yet in force in place of a
size the revision in force does not state. Such a connection is not taken off until the
port has been measured.

## T5  How sizes compare

Port sizes are nominal sizes written as a fraction (`1-1/4`, `3/4`, `2`), as a decimal
(`1.25`, `1.0`) or, by one maker, as a DN size. DN20, DN25, DN32, DN40 and DN50 are the
same sizes as `3/4`, `1`, `1-1/4`, `1-1/2` and `2` respectively. Two sizes are the SAME
size when they are numerically equal, and the LARGER of two sizes is the numerically
larger: `1-1/4`, `1.25` and `DN32` are one size, `1.0` and `1` are one size, and `1-1/2`
is larger than `1-1/4`. Sizes are never compared as text.

## T6  Which kind of fitting a connection takes

Read the two ports of the connection. Where their threads differ, the connection takes
an `ADAPTER` — a thread adapter is made in straight and reducing forms, so it covers a
size change as well. Where the threads are the same and the sizes differ, it takes a
`REDUCER`. Where the threads are the same and the sizes are the same, it takes a
`COUPLER`.

## T7  Which catalogue row

`fitting_catalog.csv` lists each fitting with its two ends, `size_a_in` with `thread_a`
and `size_b_in` with `thread_b`, every size written as a fraction and a reducer's larger
end written first. A catalogue row matches a connection when its `kind` is the kind T6
gives the connection and its two ends are the connection's two ports, each end's size
**and** thread together, in either order. Whichever end of the connection the larger port
sits at, the row is the same.

Only a row whose `status` is `STOCKED` can be selected. A `DISCONTINUED` row is never
selected, even where it matches; its `superseded_by` names the row that replaced it (blank
where nothing did), and that row is selected only if it matches the connection itself.
The catalogue never has two `STOCKED` rows with the same kind and the same two ends.

The connection's `fitting_id` is the matching `STOCKED` row's `fitting_id`. Where no
`STOCKED` row matches, the `fitting_id` is `NONE`, and the `fitting_kind` is still the
kind T6 gives: the fitting is needed and is sourced elsewhere.

## T8  Order

T1 is applied first, then T4, then the three tests of T6 in the order written; the first
that settles a connection settles it.

## T9  Pipe to cut

`total_run_ft` is the sum of `run_length_ft` in `connections.csv` over every connection
that is taken off and whose `fitting_kind` is not `UNRESOLVED`. No pipe is cut for a
withdrawn or an unresolved connection. A connection whose `fitting_id` is `NONE` is still
cut: its fitting is sourced elsewhere, its pipe is not.

## T10  What is reported

`fitting_register.csv` carries one row per connection that is taken off, in the order of
`connections.csv`. `reducer_count`, `coupler_count` and `unresolved_count` are how many
rows carry `REDUCER`, `COUPLER` and `UNRESOLVED`; a row carrying `ADAPTER` is counted by
none of them. Every connection taken off falls under exactly one kind.
