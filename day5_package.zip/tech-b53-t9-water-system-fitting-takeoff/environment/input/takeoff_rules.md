# Fitting take-off rules — house water system (Rev D)

These rules are the sole authority for the fitting each connection takes. The
connections are in `connections.csv`; each port is in `components.csv`; the sizes the
makers state are in `spec_sheet.md`; my own site measurements are in
`site_measurements.csv`; the supplier's catalogue is `fitting_catalog.csv`.

The take-off is made as at 15 September 2026. All dates are written `YYYY-MM-DD`.

## T1  Which connections are taken off

`connections.csv` still carries runs that have since been re-routed. Where a connection's
`connection_id` appears in the `replaces` column of another connection, it is WITHDRAWN:
it gets no row in the register, it is counted by none of the counts, and no pipe is cut
for it. Every other connection is taken off, replacements included, unless another
connection replaces them in turn. A blank `replaces` means the connection replaces
nothing.

## T2  Which maker's table is in force

Makers publish revised port tables, sometimes ahead of the date they take effect. A
revision is in force from its effective date, so it counts when that date is on or before
the take-off date and does not count when it is later. The publication date plays no
part. Each revision is either a reissue or an amendment:

- A reissue replaces the earlier table whole. A port a reissue does not state is not
  stated, whatever an earlier revision said.
- An amendment changes only the rows it lists; every other row stays as it was.

The table in force for a product is its latest reissue in force, with every amendment in
force that is effective after that reissue applied to it in effective-date order.

## T3  Where a port's size and thread come from

A port's SIZE is the size the table in force (T2) states for the component's `product`
and `port_role`. A port's THREAD is the `thread` column of `components.csv`. The
`listed_size_in` column of `components.csv` is what the retailer's listing says; it is
carried for reference and no rule below reads it.

## T4  A port the table in force does not state

Where the table in force states no size for a port, the port's size is the one I measured
for that `component_id` in `site_measurements.csv` on or before the take-off date; where I
measured it more than once by then, the latest such measurement counts. A measurement is
used only for a port the table in force does not state: it never replaces a size the
table in force states.

Where the table in force states no size for a port and no measurement counts for it,
every connection that has that port (its `component_id`) at either end is `UNRESOLVED`,
and its `fitting_id` is `NONE`. The other ports of the same product are unaffected. No
size is taken from a listing, a kit, a description or a revision not in force. Such a
connection is not taken off until the port has been measured.

## T5  How sizes compare

Port sizes are nominal sizes written as a fraction (`1-1/4`, `3/4`, `2`), as a decimal
(`1.25`, `1.0`) or, by one maker, as a DN size. DN20, DN25, DN32, DN40 and DN50 are the
same sizes as `3/4`, `1`, `1-1/4`, `1-1/2` and `2` respectively. Two sizes are the SAME
size when they are numerically equal, and the LARGER of two sizes is the numerically
larger: `1-1/4`, `1.25` and `DN32` are one size, `1.0` and `1` are one size, and `1-1/2`
is larger than `1-1/4`. Sizes are never compared as text.

## T6  Which kind of fitting a connection takes

Read the two ports of the connection. Where their threads differ, the connection takes
an `ADAPTER` — a thread adapter is made in straight and reducing forms, so it covers a
size change as well. Where the threads are the same and the sizes differ, it takes a
`REDUCER`. Where the threads are the same and the sizes are the same, it takes a
`COUPLER`.

## T7  Which catalogue row

`fitting_catalog.csv` lists each fitting with its two ends, `size_a_in` with `thread_a`
and `size_b_in` with `thread_b`, every size written as a fraction and a reducer's larger
end written first. A catalogue row matches a connection when its `kind` is the kind T6
gives the connection and its two ends are the connection's two ports, each end's size and
thread together, in either order.

Only a row whose `status` is `STOCKED` can be selected. A `DISCONTINUED` row is never
selected, even where it matches; its `superseded_by` names the row that replaced it (blank
where nothing did), and that row is selected only if it matches the connection itself.
The catalogue never has two `STOCKED` rows with the same kind and the same two ends.

The connection's `fitting_id` is the matching `STOCKED` row's `fitting_id`. Where no
`STOCKED` row matches, the `fitting_id` is `NONE`, and the `fitting_kind` is still the
kind T6 gives: the fitting is needed and is sourced elsewhere.

## T8  Order

T1 is applied first, then T4, then the three tests of T6 in the order written; the first
that settles a connection settles it.

## T9  Pipe to cut

`total_run_ft` is the sum of `run_length_ft` in `connections.csv` over every connection
that is taken off and whose `fitting_kind` is not `UNRESOLVED`. No pipe is cut for a
withdrawn or an unresolved connection. A connection whose `fitting_id` is `NONE` is still
cut: its fitting is sourced elsewhere, its pipe is not.

## T10  What is reported

`fitting_register.csv` carries one row per connection that is taken off, in the order of
`connections.csv`. `reducer_count`, `coupler_count` and `unresolved_count` are how many
rows carry `REDUCER`, `COUPLER` and `UNRESOLVED`; a row carrying `ADAPTER` is counted by
none of them. Every connection taken off falls under exactly one kind.
