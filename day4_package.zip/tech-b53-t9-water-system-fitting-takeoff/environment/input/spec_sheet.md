# Manufacturer port data — specification extracts

Extracted from the manufacturers' own published tables for every product on `components.csv`, matched by `product` and `port_role`. Each table gives the size the manufacturer STATES for a port, in the manufacturer's own notation: most makers print fractions (`1-1/4`), one prints decimals (`1.25`) and one prints DN sizes (`DN32`). Where a maker has revised a table, every revision is extracted with its effective date and its publication date. Where the manufacturer states no size, the table says so in words. A retailer listing, a supplied kit or a product description is quoted only for the record and states nothing.

## Cistern-Line CT-500 storage tank (500 gal) — product `CT-500`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev 1 — effective 2023-05-02 (published 2023-04-20)

| port_role | manufacturer's stated port size |
|---|---|
| TANK_OUT | 1-1/2 |

## Cistern-Line CT-1500 storage tank (1500 gal) — product `CT-1500`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev 1 — effective 2022-11-14 (published 2022-11-01)

| port_role | manufacturer's stated port size |
|---|---|
| TANK_OUT | 2 |

## Cistern-Line CT-300 storage tank (300 gal) — product `CT-300`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev 1 — effective 2025-03-03 (published 2025-02-17)

| port_role | manufacturer's stated port size |
|---|---|
| TANK_OUT | 1 |

## Rainbarrel RB-800 reservoir (800 gal) — product `RB-800`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev 1 — effective 2021-06-01 (published 2021-05-12)

| port_role | manufacturer's stated port size |
|---|---|
| TANK_OUT | 1-1/4 |

## Torrent TJ-100 shallow-well jet pump — product `TJ-100`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev 2 — effective 2026-10-01 (published 2026-08-28)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1-1/4 |
| DISCHARGE | 1 |

### Rev 1 — effective 2024-01-15 (published 2023-12-20)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | not stated — the manufacturer's table gives no suction port size |
| DISCHARGE | 1 |

Retailer listing, quoted for the record: "supplied with a 1-1/4 in. suction kit; plumb the suction with 1-1/4 in. pipe and the discharge with 1 in." The listing describes the kit, not the port.

## Torrent TJ-150 shallow-well jet pump — product `TJ-150`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev 1 — effective 2024-07-01 (published 2024-06-10)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1-1/4 |
| DISCHARGE | 1 |

Retailer listing, quoted for the record: "1-1/4 in. suction and 1-1/4 in. discharge" The manufacturer's table states 1 for the discharge port.

## Torrent TJ-200 deep-well jet pump — product `TJ-200`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev 2 — effective 2026-09-16 (published 2026-09-01)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1-1/2 |
| DISCHARGE | 1-1/4 |

### Rev 1 — effective 2025-02-01 (published 2025-01-15)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | not stated — the manufacturer's table gives no suction port size |
| DISCHARGE | 1-1/4 |

## Brookline BJ-75 jet pump — product `BJ-75`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev 1 — effective 2024-03-01 (published 2024-02-12)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1-1/2 |
| DISCHARGE | 1-1/4 |

### Rev 2 — effective 2026-06-01 (published 2026-05-15)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1-1/2 |
| DISCHARGE | 1 |

## Hydra-Jet HJ-1 jet pump — product `HJ-1`

Sizes in these tables are printed as the maker prints them (decimals).

### Rev 2 — effective 2026-09-15 (published 2026-07-30)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1.25 |
| DISCHARGE | 1.25 |

### Rev 1 — effective 2022-09-01 (published 2022-08-15)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1.25 |
| DISCHARGE | 1.0 |

## Aquaflux AF-40 booster pump — product `AF-40`

Sizes in these tables are printed as the maker prints them (DN sizes).

### Rev 1 — effective 2025-05-20 (published 2025-05-02)

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | DN40 |
| DISCHARGE | DN25 |

## Pressurite PV-20 pressure vessel — product `PV-20`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev A — effective 2023-02-01 (published 2023-01-18)

| port_role | manufacturer's stated port size |
|---|---|
| VESSEL_IN | 1 |

## Pressurite PV-44 pressure vessel — product `PV-44`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev B — effective 2026-11-01 (published 2026-08-20)

| port_role | manufacturer's stated port size |
|---|---|
| VESSEL_IN | 1 |

### Rev A — effective 2023-01-10 (published 2022-12-19)

| port_role | manufacturer's stated port size |
|---|---|
| VESSEL_IN | 1-1/4 |

## Pressurite PV-60 pressure vessel — product `PV-60`

Sizes in these tables are printed as the maker prints them (fractions).

### Rev A — effective 2023-02-01 (published 2023-01-18)

| port_role | manufacturer's stated port size |
|---|---|
| VESSEL_IN | 3/4 |

### Rev B — effective 2026-04-01 (published 2026-03-10)

| port_role | manufacturer's stated port size |
|---|---|
| VESSEL_IN | not stated — the manufacturer's table gives no vessel_in port size |

## Aquaflux AV-50 pressure vessel — product `AV-50`

Sizes in these tables are printed as the maker prints them (DN sizes).

### Rev 1 — effective 2025-05-20 (published 2025-05-02)

| port_role | manufacturer's stated port size |
|---|---|
| VESSEL_IN | DN32 |
