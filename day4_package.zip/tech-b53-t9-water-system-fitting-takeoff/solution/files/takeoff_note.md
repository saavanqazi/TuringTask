# Fitting take-off — house water system, as at 15 September 2026

The register filed with this note carries one row for every connection that is being taken off: the catalogue fitting it takes and what kind of fitting that is. Runs that have since been re-routed are left out, and their replacements are listed instead. Port sizes come from the makers' tables in force on the take-off date, not from the retailer's listings.

Connections needing a reducer: 10. Connections needing a coupler: 3. The remaining connections change thread standard and take adapters.

Where no stocked catalogue row fits (C-04, C-20), the kind still stands and the fitting will be sourced elsewhere; the pipe for those runs is still cut.

C-25, C-11, C-10 and C-24 are held off the take-off as unresolved: for each of them the maker's table in force gives no size for one of the two ports, and nothing is taken from a listing, an earlier revision or a revision not yet in force. No fitting is ordered and no pipe is cut for these runs until the port has been measured.

Pipe to cut in total: 171.5 ft.
