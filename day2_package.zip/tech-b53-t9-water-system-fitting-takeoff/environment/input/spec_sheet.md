# Manufacturer port data — specification extracts

Extracted from the manufacturers' own published tables for every product on `components.csv`, matched by `product` and `port_role`. Each table gives the size the manufacturer STATES for a port, in the manufacturer's own notation: some makers print fractions (`1-1/4`) and one prints decimals (`1.25`). Where the manufacturer states no size, the table says so in words. A retailer listing, a supplied kit or a product description is quoted only for the record and states nothing.

## Cistern-Line CT-500 storage tank (500 gal) — product `CT-500`

Sizes in this table are printed as the maker prints them (fractions).

| port_role | manufacturer's stated port size |
|---|---|
| TANK_OUT | 1-1/2 |

## Cistern-Line CT-1500 storage tank (1500 gal) — product `CT-1500`

Sizes in this table are printed as the maker prints them (fractions).

| port_role | manufacturer's stated port size |
|---|---|
| TANK_OUT | 2 |

## Rainbarrel RB-800 reservoir (800 gal) — product `RB-800`

Sizes in this table are printed as the maker prints them (fractions).

| port_role | manufacturer's stated port size |
|---|---|
| TANK_OUT | 1-1/4 |

## Torrent TJ-100 shallow-well jet pump — product `TJ-100`

Sizes in this table are printed as the maker prints them (fractions).

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | not stated — the manufacturer's table gives no suction port size |
| DISCHARGE | 1 |

Retailer listing, quoted for the record: "supplied with a 1-1/4 in. suction kit; plumb the suction with 1-1/4 in. pipe and the discharge with 1 in." The listing describes the kit, not the port.

## Torrent TJ-150 shallow-well jet pump — product `TJ-150`

Sizes in this table are printed as the maker prints them (fractions).

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1-1/4 |
| DISCHARGE | 1 |

Retailer listing, quoted for the record: "1-1/4 in. suction and 1-1/4 in. discharge" The manufacturer's table states 1 for the discharge port.

## Brookline BJ-75 jet pump — product `BJ-75`

Sizes in this table are printed as the maker prints them (fractions).

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1-1/2 |
| DISCHARGE | 1-1/4 |

## Hydra-Jet HJ-1 jet pump — product `HJ-1`

Sizes in this table are printed as the maker prints them (decimals).

| port_role | manufacturer's stated port size |
|---|---|
| SUCTION | 1.25 |
| DISCHARGE | 1.0 |

## Pressurite PV-20 pressure vessel — product `PV-20`

Sizes in this table are printed as the maker prints them (fractions).

| port_role | manufacturer's stated port size |
|---|---|
| VESSEL_IN | 1 |

## Pressurite PV-44 pressure vessel — product `PV-44`

Sizes in this table are printed as the maker prints them (fractions).

| port_role | manufacturer's stated port size |
|---|---|
| VESSEL_IN | 1-1/4 |

## Pressurite PV-60 pressure vessel — product `PV-60`

Sizes in this table are printed as the maker prints them (fractions).

| port_role | manufacturer's stated port size |
|---|---|
| VESSEL_IN | 3/4 |
