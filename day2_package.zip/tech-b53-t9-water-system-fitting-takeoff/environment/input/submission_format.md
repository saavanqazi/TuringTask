# Submission format

Save exactly these files in `/app`:

- `fitting_register.csv` — One row per connection: the catalogue fitting it takes and what kind of fitting that is
- `takeoff_note.md` — The short note that goes to the plumbing supplier with the register
- `results.json` — a JSON object; see below.

## `fitting_register.csv`

Header, exactly: `connection_id,fitting_id,fitting_kind`
One row per record, keyed by `connection_id`.
`fitting_kind` takes exactly one of: `COUPLER`, `REDUCER`, `ADAPTER`, `UNRESOLVED`.
One row per connection in `connections.csv`, in that file's order. `fitting_id` is the `fitting_id` of the catalogue row `takeoff_rules.md` selects for the connection, spelled exactly as `fitting_catalog.csv` spells it, hyphens and capitals included, or `NONE` where the rules select no catalogue row. `fitting_kind` is one token from the vocabulary above and nothing else.

Example (placeholder values):

```
connection_id,fitting_id,fitting_kind
C-00,XX-0-0-X,COUPLER
```

## `takeoff_note.md`

A short note in plain prose for the supplier. It must:

- state how many connections need a reducer and how many need a coupler. Each is the number of rows your register marks `REDUCER` or `COUPLER`. Put each number in the same sentence as the word *reducer* or *coupler*, either way round, in digits or in words.
- name every connection your register marks `UNRESOLVED` by its `connection_id`, exactly as `connections.csv` writes it (for example `C-00`). Put the word *unresolved* in the same paragraph, with no other connection's `connection_id` between the two.

These facts are what is checked. The rest of the wording is up to you.

## `results.json`

A JSON object with exactly these keys and nothing else:

- `reducer_count` — number
- `coupler_count` — number
- `unresolved_count` — number
- `total_run_ft` — number

Shape example (placeholder values):

```json
{
  "reducer_count": 0,
  "coupler_count": 0,
  "unresolved_count": 0,
  "total_run_ft": 0
}
```

`reducer_count`, `coupler_count` and `unresolved_count` are counts of the rows of your own register carrying `REDUCER`, `COUPLER` and `UNRESOLVED`, as `takeoff_rules.md` rule T8 sets them out; a row carrying `ADAPTER` is counted by none of them. `total_run_ft` is the sum of `run_length_ft` in `connections.csv` over the connections your register does not mark `UNRESOLVED`, as rule T7 sets it out, written as a plain number giving the exact sum (`12.5`, never `12.5 ft` or `12,5`).
