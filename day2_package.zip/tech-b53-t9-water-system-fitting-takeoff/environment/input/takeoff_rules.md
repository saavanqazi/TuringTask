# Fitting take-off rules — house water system (Rev B)

These rules are the sole authority for the fitting each connection takes. The
connections are in `connections.csv`; each port is in `components.csv`; the sizes the
makers state are in `spec_sheet.md`; the fittings the supplier stocks are in
`fitting_catalog.csv`.

## T1  Where a port's size and thread come from

A port's SIZE is the size the manufacturer states for the component's `product` and
`port_role` in `spec_sheet.md`. A port's THREAD is the `thread` column of
`components.csv`. The `listed_size_in` column of `components.csv` is what the retailer's
listing says; it is carried for reference and no rule below reads it.

## T2  A port the manufacturer does not state

Where `spec_sheet.md` says in words that the manufacturer states no size for a port,
every connection that has that port (its `component_id` in `components.csv`) at either
end is `UNRESOLVED`, and its `fitting_id` is `NONE`. The other ports of the same product
are unaffected: each is read from its own row of the maker's table. No size is taken from
a listing, a kit or a description in place of a size the manufacturer does not state.
Such a connection is not taken off until the port has been measured.

## T3  How sizes compare

Port sizes are nominal sizes written as a fraction (`1-1/4`, `3/4`, `2`) or as a decimal
(`1.25`, `1.0`). Two sizes are the SAME size when they are numerically equal, and the
LARGER of two sizes is the numerically larger: `1-1/4` and `1.25` are one size, `1.0` and
`1` are one size, and `1-1/2` is larger than `1-1/4`. Sizes are never compared as text.

## T4  Which kind of fitting a connection takes

Read the two ports of the connection. Where their threads differ, the connection takes
an `ADAPTER` — a thread adapter is made in straight and reducing forms, so it covers a
size change as well. Where the threads are the same and the sizes differ, it takes a
`REDUCER`. Where the threads are the same and the sizes are the same, it takes a
`COUPLER`.

## T5  Which catalogue row

`fitting_catalog.csv` lists each stocked fitting with its two ends, `size_a_in` with
`thread_a` and `size_b_in` with `thread_b`, every size written as a fraction and a
reducer's larger end written first. A catalogue row matches a connection when its `kind`
is the kind T4 gives the connection and its two ends are the connection's two ports, in
either order. Whichever end of the connection the
larger port sits at, the row is the same. The connection's `fitting_id` is that row's
`fitting_id`. Where no row matches, the `fitting_id` is `NONE`, and the
`fitting_kind` is still the kind T4 gives: the fitting is needed and is sourced
elsewhere.

## T6  Order

T2 is applied first, then the three tests of T4 in the order written, and the first that settles a connection settles it.

## T7  Pipe to cut

`total_run_ft` is the sum of `run_length_ft` in `connections.csv` over every connection
whose `fitting_kind` is not `UNRESOLVED`. No pipe is cut for an unresolved connection.
A connection whose `fitting_id` is `NONE` is still cut: its fitting is sourced
elsewhere, its pipe is not.

## T8  What is reported

`fitting_register.csv` carries one row per connection in `connections.csv`, in that
file's order. `reducer_count`, `coupler_count` and `unresolved_count` are how many rows
carry `REDUCER`, `COUPLER` and `UNRESOLVED`; a row carrying `ADAPTER` is counted by
none of them. Every connection falls under exactly one kind.
