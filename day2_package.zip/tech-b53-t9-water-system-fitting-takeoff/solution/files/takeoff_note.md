# Fitting take-off — house water system, tanks to pumps to pressure vessels

Every connection on the list was taken off against the makers' port tables and the
supplier's catalogue, and the register filed with this note carries one row per
connection: the catalogue fitting it takes and what kind of fitting that is. Most of the
runs change size between their two ports, a few change thread standard as well, and a
couple join like to like.

Connections needing a reducer: 9. Each of those runs between two
ports of the same thread standard and different sizes, the larger port always keyed
first in the catalogue whichever end of the run it sits at, and one of them has no
catalogue row at all — the kind stands and the fitting is sourced elsewhere.

Connections needing a coupler: 2. Their ports are the same size at
both ends once the sizes are read as numbers rather than as the strings the two makers
happen to print.

C-03 is the one connection held off the take-off altogether: its `fitting_kind` is
`UNRESOLVED`. The tank end is stated plainly enough, but the pump maker's table gives
no suction port size at all, and the retailer's listing — which has the pump plumbed
with a particular suction pipe — describes a kit, not the port. Nothing is taken from a
listing in place of a stated size, so no fitting is ordered and no pipe is cut for that
run until the port has been measured, and its length is left out of the pipe total.

The thread changes on the list are all covered by catalogue adapters, and the total pipe
to cut in `results.json` is the sum over the connections that are taken off, which is
every connection except the one above.
